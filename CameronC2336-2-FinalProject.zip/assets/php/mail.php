<?php
$name = $_POST['name'];
$visitor_email = $_POST['email'];
$phone = $_POST['phone'];
$message = $_POST['message'];

$email_from = 'http://ckciampi.heyuhnem.com/cameron-ciampichini-contact.html';

$email_subject = "Contact Form";

$email_body= "Name: $name \n".
  "Phone: $phone \n".
  "Message: $message \n";

$recipient = "mviseh@uh.edu";

$headers = "From: $visitor_email \r\n";
$headers .= "Reply To: $visitor_email \r\n";

mail($recipient,$email_subject,$email_body,$headers) or die("Error!");
echo "Thank you for your message!" . " -" . "<a href='http://ckciampi.heyuhnem.com/index.html' style='text-decoration:none;color:#0000FF;'> Return Home</a>";
?>
